/**
* @author Yehan Li
* @file main.cpp
* @since 30 October 2016
* @brief A Tower Defense Program.
* Watched tutorials that helped me from the flowing websites:
* 
* https://www.youtube.com/watch?v=H3Dn1CQsREw
* https://www.youtube.com/watch?v=Euiqdd09n68
* https://www.youtube.com/watch?v=7QDz81jMsF8
* https://www.youtube.com/watch?v=uwp-xW0kylc&t=5s
* https://www.youtube.com/watch?v=qoi6ASLK7iI
* https://www.youtube.com/watch?v=0v56I5UWrYY&list=PL19F2453814E0E315
*/
package MyAsistant;

import static org.lwjgl.opengl.GL11.*;

import java.io.IOException;
import java.io.InputStream;

import org.lwjgl.LWJGLException;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;

import org.newdawn.slick.opengl.Texture;
import org.newdawn.slick.opengl.TextureLoader;
import org.newdawn.slick.util.ResourceLoader;

public class Asistant {
	
	public static final int WIDTH= 1472, HEIGHT= 960;
	
	/**
	 * Create a window to run the game
	 */
	public static void View()
	{
		Display.setTitle("Yehan's Tower Defense Game!");
		try {
			Display.setDisplayMode(new DisplayMode(1472,960)); //(width,height) of a window
			Display.create();
		} catch (LWJGLException e) {
			e.printStackTrace();
		}
		//glMatrixMode �� specify which matrix is the current matrix
		glMatrixMode(GL_PROJECTION);//defines the properties of the camera that views the objects in the world coordinate frame
		glLoadIdentity();//glLoadIdentity �� replace the current matrix with the identity matrix.Resets the matrix back to its default state. What You Learned in Math 290.
						 //It initializes your matrix to the right state before you multiply further matrices into the matrix stack.
		glOrtho(0, WIDTH, HEIGHT, 0, 1, -1); //setting camera(most left, most right, most bottom, most top, 3d setting, 3d setting) top left is (0,0)
		glMatrixMode(GL_MODELVIEW);//defines how your objects are transformed (meaning translation,rotation and scaling) in your world coordinate frame
		glEnable(GL_TEXTURE_2D);//draw textures to the screen
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	}
	
	/**
	 * draw a square on the window
	 * @param x x
	 * @param y y
	 * @param width width
	 * @param height height
	 */
	public static void DrawSquare(float x, float y, float width, float height)
	{
		glBegin(GL_QUADS);
		glVertex2f(x, y);
		glVertex2f(x+width, y);
		glVertex2f(x+width, y+height);
		glVertex2f(x, y +height);
		glEnd();
	}
	
	/**
	 * Draw the square with an image
	 * @param tex
	 * @param x
	 * @param y
	 * @param width
	 * @param height
	 */
	public static void DrawSquareTex(Texture tex, float x, float y, float width, float height)
	{
		tex.bind();// bind texture to opengl
		glTranslatef(x, y, 0);//2d No need for Z. Set current work location to (x,y), but use (0,0) to represent (x, y)
		glBegin(GL_QUADS);
		glTexCoord2f(0, 0);
		glVertex2f(0, 0);
		glTexCoord2f(1, 0);
		glVertex2f(width, 0);
		glTexCoord2f(1, 1);
		glVertex2f(width, height);
		glTexCoord2f(0, 1);
		glVertex2f(0, height);
		glEnd();
		glLoadIdentity();
	}
	
	/**
	 * Give the square with an image
	 * @param location
	 * @param Type
	 * @return Texture
	 */
	public static Texture SetTexture(String location, String Type)
	{
		Texture texture = null;
		InputStream input = ResourceLoader.getResourceAsStream(location);
		try {
			texture = TextureLoader.getTexture(Type, input);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return texture;
	}
	
	/**
	 * 
	 * @param name name of the image
	 * @return texture
	 */
	public static Texture Fload(String name)
	{
		Texture texture = null;
		texture = SetTexture("Resources/" + name + ".png", "PNG");
		return texture;
		
	}

}
