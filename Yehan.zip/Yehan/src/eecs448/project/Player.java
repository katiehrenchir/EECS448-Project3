/**
* @author Yehan Li
* @file main.cpp
* @since 30 October 2016
* @brief A Tower Defense Program.
* Watched tutorials that helped me from the flowing websites:
* 
* https://www.youtube.com/watch?v=H3Dn1CQsREw
* https://www.youtube.com/watch?v=Euiqdd09n68
* https://www.youtube.com/watch?v=7QDz81jMsF8
* https://www.youtube.com/watch?v=uwp-xW0kylc&t=5s
* https://www.youtube.com/watch?v=qoi6ASLK7iI
* https://www.youtube.com/watch?v=0v56I5UWrYY&list=PL19F2453814E0E315
*/
package eecs448.project;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import static MyAsistant.Asistant.*;

public class Player {
	
	private Grid g;
	private SquareType[] t;
	private int marker;
	
	/**
	 * the constructor a player
	 * @param g A Grid
	 */
	public Player(Grid g)
	{
		this.g = g;
		this.t = new SquareType[3];
		this.t[0] = SquareType.Grass;
		this.t[1] = SquareType.River;
		this.t[2] = SquareType.Road;
		this.marker = 0;
	}
	
	/**
	 * Set a square to a type
	 */
	public void SetSquare()
	{
		g.SetSquare((int)Math.floor(Mouse.getX() / 64), (int)Math.floor((HEIGHT - Mouse.getY() - 1)/64), t[marker]);
	}
	
	/**
	 * Detect clicks
	 */
	public void update()
	{
		if(Mouse.isButtonDown(0))//0 = left click, 1= right click
		{
			SetSquare();
		}
		
		while(Keyboard.next())
		{
			if(Keyboard.getEventKey() == Keyboard.KEY_RIGHT && Keyboard.getEventKeyState())
			{
				ChangeMarker();
			}
		}
	}
	
	/**
	 * Change the marker of square types in an order
	 * marker is the indicator of the array size of squaretype
	 */
	public void ChangeMarker()
	{
		marker = marker +1;
		if(marker > t.length - 1)
		{
			marker = 0;
		}
	}
	
}
