package eecs448.project;

import static MyAsistant.Asistant.*;

public class Grid {
	public Square[][] field;
	/**
	 * Created a grid
	 */
	public Grid()
	{
		field = new Square[23][15];
		for(int i = 0; i < field.length; i++ )
		{
			for(int j= 0; j < field[i].length; j++)
			{
				field[i][j] = new Square(i * 64, j * 64, 64, 64, SquareType.Grass);
			}
		}
	}
	/**
	 * Create a grid with an array parameter
	 * @param newfield
	 */
	public Grid(int[][] newfield)
	{
		field = new Square[23][15];
		for(int i = 0; i < field.length; i++ )
		{
			for(int j= 0; j < field[i].length; j++)
			{
				switch(newfield[j][i])
				{
				case 0:
					field[i][j] = new Square(i * 64, j * 64, 64, 64, SquareType.Grass);
					break;
				case 1:
					field[i][j] = new Square(i * 64, j * 64, 64, 64, SquareType.Road);
					break;
				case 2:
					field[i][j] = new Square(i * 64, j * 64, 64, 64, SquareType.River);
					break;
				}
			}
		}
	}
	
	/**
	 * Set a Square
	 * @param xco X position
	 * @param yco Y Position
	 * @param t A type of square
	 */
	public void SetSquare(int xco, int yco, SquareType t)
	{
		field[xco][yco] = new Square(xco * 64, yco * 64, 64, 64, t);
	}
	
	/**
	 * get a square
	 * @param xco X Position
	 * @param yco Y Position
	 * @return A SquareType
	 */
	public Square GetSquare(int xco, int yco)
	{
		return field[xco][yco];
	}
	
	/**
	 * Draw the Map
	 */
	public void Draw()
	{
		for(int i = 0; i < field.length; i++ )
		{
			for(int j= 0; j < field[i].length; j++)
			{
				field[i][j].Draw();
			}
		}
	}

}
