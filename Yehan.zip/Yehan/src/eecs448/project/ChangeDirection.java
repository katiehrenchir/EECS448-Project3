package eecs448.project;

public class ChangeDirection //save the next step and direction
{
	private Square turn; //the current square
	private int VDir, HDir;//the direction of a square
	
	/**
	 * Constructor
	 * @param turn A Corner
	 * @param HDir The X direction
	 * @param VDir The Y direction
	 */
	public ChangeDirection(Square turn, int HDir, int VDir)
	{
		this.turn = turn;
		this.VDir = VDir;
		this.HDir = HDir;
		
	}

	/**
	 * Get the Corner
	 * @return
	 */
	public Square getTurn() {
		return turn;
	}

	/**
	 * Get the Y direction
	 * @return Y direction
	 */
	public int getVDir() {
		return VDir;
	}

	/**
	 * Get the X direction
	 * @return X direction
	 */
	public int getHDir() {
		return HDir;
	}

}
