
package eecs448.project;

import java.util.ArrayList;
import static MyAsistant.Time.*;

public class Group {

	private float lSpawn, SpawnT;
	private Monster t;
	private ArrayList<Monster> Mlist;
	/**
	 * 
	 * @param SpawnT Spawn Time 
	 * @param t a monster
	 */
	public Group(float SpawnT, Monster t)
	{
		this.t = t;
		this.SpawnT = SpawnT;
		lSpawn = 0;
		Mlist = new ArrayList<Monster>();
	}
	
	/**
	 * Populate the monster group and show it on the window
	 */
	public void update()
	{
		lSpawn += Delta();
		if(lSpawn > SpawnT)
		{
			Spawn();
			lSpawn = 0;
		}
		
		for (Monster m: Mlist)
		{
			m.update();
			m.Draw();
		}
	}
	
	/**
	 * Spawn a Monster
	 */
	public void Spawn()
	{
		Mlist.add(new Monster(t.getTex(), t.getGrid(), t.getS(), 64, 64, t.getSpeed()));
	}
}
