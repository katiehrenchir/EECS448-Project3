package eecs448.project;

import org.newdawn.slick.opengl.Texture;
import static MyAsistant.Asistant.*;

public class Square {
	private float x, y, width, height;
	private Texture texture;
	private SquareType type;
	/**
	 * 
	 * @param x x coordinate
	 * @param y y coordinate
	 * @param width width
	 * @param height height
	 * @param type type
	 */
	public Square(float x, float y, float width, float height, SquareType type)
	{
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.type=type;
		this.texture = Fload(type.texName);
	}
	
	/**
	 * Draw a square
	 */
	public void Draw()
	{
		DrawSquareTex(texture, x, y, width, height);
	}
	/**
	 * get X
	 * @return
	 */
	public float getX() {
		return x;
	}
	
	/**
	 * Get X in integers
	 * @return
	 */
	public int getIX()
	{
		return (int)x/64;
	}
	/**
	 * set X
	 * @param x
	 */
	public void setX(float x) {
		this.x = x;
	}
	
	/**
	 * get Y
	 * @return y
	 */
	public float getY() {
		return y;
	}
	
	/**
	 * Get Y in integers
	 * @return int
	 */
	public int getIY()
	{
		return (int)y/64;
	}
	
	/**
	 * Set Y
	 * @param y
	 */
	public void setY(float y) {
		this.y = y;
	}
	/**
	 * get Width of a square
	 * @return
	 */
	public float getWidth() {
		return width;
	}
	/**
	 * Set Width of a square
	 * @param width
	 */
	public void setWidth(float width) {
		this.width = width;
	}
	/**
	 * Get Height
	 * @return height
	 */
	public float getHeight() {
		return height;
	}
	/**
	 * Set Height
	 * @param height
	 */
	public void setHeight(float height) {
		this.height = height;
	}
	/**
	 * Get Texture
	 * @return texture
	 */
	public Texture getTexture() {
		return texture;
	}
	/**
	 * Set texture
	 * @param texture
	 */
	public void setTexture(Texture texture) {
		this.texture = texture;
	}
	/**
	 * Get Type
	 * @return type
	 */
	public SquareType getType() {
		return type;
	}
	/**
	 * Set Type
	 * @param type
	 */
	public void setType(SquareType type) {
		this.type = type;
	}
}
