/**
* @author Yehan Li
* @file main.cpp
* @since 30 October 2016
* @brief A Tower Defense Program.
* Watched tutorials that helped me from the flowing websites:
* 
* https://www.youtube.com/watch?v=H3Dn1CQsREw
* https://www.youtube.com/watch?v=Euiqdd09n68
* https://www.youtube.com/watch?v=7QDz81jMsF8
* https://www.youtube.com/watch?v=uwp-xW0kylc&t=5s
* https://www.youtube.com/watch?v=qoi6ASLK7iI
* https://www.youtube.com/watch?v=0v56I5UWrYY&list=PL19F2453814E0E315
*/
package eecs448.project;

public enum SquareType {
	
	Grass("grass", true), Road("road", false), River("river", false);
	
	String texName;
	boolean enable;
	
	/**
	 * Set a type a texture
	 * @param texName the name of a texture
	 * @param enable whether it is enabled
	 */
	SquareType(String texName, boolean enable)
	{
		this.texName = texName;
		this.enable = enable;
	}

}
