package eecs448.project;

public enum SquareType {
	
	Grass("grass", true), Road("road", false), River("river", false);
	
	String texName;
	boolean enable;
	
	/**
	 * Set a type a texture
	 * @param texName the name of a texture
	 * @param enable whether it is enabled
	 */
	SquareType(String texName, boolean enable)
	{
		this.texName = texName;
		this.enable = enable;
	}

}
