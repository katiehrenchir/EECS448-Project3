package Entity;

import java.awt.Rectangle;

import TileMap.Tile;
import TileMap.TileMap;
import Main.GamePanel;

public abstract class MapObject {
	// tiles
	protected TileMap tileMap;
	protected int tileSize;
	protected double xmap;
	protected double ymap;
	
	// position and vector
	protected double x;
	protected double y;
	protected double dx;
	protected double dy;
	
	// dimensions
	protected int width;
	protected int height;
	
	// collision box
	protected int cwidth;
	protected int cheight;
	
	// collision
	protected int currRow;
	protected int currCol;
	protected double xdest;
	protected double ydest;
	protected double xtemp;
	protected double ytemp;
	protected boolean topLeft;
	protected boolean topRight;
	protected boolean bottomLeft;
	protected boolean bottomRight;
	
	// animation
	protected Animation animation;
	protected Animation warningAnimation;
	protected Animation strikeAnimation;
	protected int currentAction;
	protected int previousAction;
	protected boolean facingRight;
	
	// movement
	protected boolean left;
	protected boolean right;
	protected boolean up;
	protected boolean down;
	protected boolean jumping;
	protected boolean falling;
	
	// movement attributes ("physics")
	protected double moveSpeed;
	protected double maxSpeed;
	protected double stopSpeed;
	protected double fallSpeed; //gravity
	protected double maxFallSpeed; //terminal velocity
	protected double jumpStart; //how high object can jump
	protected double stopJumpSpeed; //when jump is held, jump higher
	
	protected double maxHealth;
	
	// actions
	protected boolean lightningStrike;
	protected boolean dropping;
	
	
	// constructor
	public MapObject(TileMap tm) {
		tileMap = tm;
		tileSize = tm.getTileSize();
	}
	
	
	
	public boolean intersects(MapObject o) {
		Rectangle r1 = getRectangle();
		Rectangle r2 = o.getRectangle();
		return r1.intersects(r2);
	}
	
	
	
	public Rectangle getRectangle() {
		return new Rectangle(
				(int)x - cwidth,
				(int)y - cheight,
				cwidth, 
				cheight
		);
	}
	
	
	
	public void calculateCorners(double x, double y) {
        int leftTile =   (int)(x - cwidth / 2) / tileSize;
        int rightTile =  (int)(x + cwidth / 2 - 1) / tileSize;
        int topTile =    (int)(y - cheight / 2) / tileSize;
        int bottomTile = (int)(y + cheight / 2 - 1) / tileSize;
        
        if(topTile < 0 || bottomTile >= tileMap.getNumRows() ||
           leftTile < 0 || rightTile >= tileMap.getNumCols()) {
                topLeft = topRight = bottomLeft = bottomRight = false;
                return;
        }
              
        int tl = tileMap.getType(topTile, leftTile);
        int tr = tileMap.getType(topTile, rightTile);
        int bl = tileMap.getType(bottomTile, leftTile);
        int br = tileMap.getType(bottomTile, rightTile);
        
        topLeft =     (tl == Tile.BLOCKED);
        topRight =    (tr == Tile.BLOCKED);
        bottomLeft =  (bl == Tile.BLOCKED);
        bottomRight = (br == Tile.BLOCKED);
	}
	
	
	
	public void checkTileMapCollision() {
		currCol = (int)x / tileSize;
		currRow = (int)y / tileSize;
		
		xdest = x+dx;
		ydest = y+dy;
		
		xtemp = x;
		ytemp = y;
		
		// check collision for y movement:
		calculateCorners(x, ydest);
		if(dy < 0) {
			if(topLeft || topRight) {
				dy = 0; //stop moving upward
				ytemp = currRow*tileSize + cheight/2; //set the object just below that boundary 
			} else {
				ytemp += dy; //otherwise, keep moving
			}
		}
		if(dy > 0) {
			if(bottomLeft || bottomRight) {
				dy = 0; //stop moving downward
				falling = false;
				ytemp = (currRow + 1)*tileSize - cheight/2; //set the object just above that boundary
			} else {
				ytemp += dy; //otherwise, keep moving
			}
		}
		
		// check collision for x movement:
		calculateCorners(xdest,y); 
		if(dx < 0){
			if(topLeft || bottomLeft) {
				dx = 0; //stop moving leftward
				xtemp = currCol*tileSize + cwidth/2; //set the object just before that boundary
			} else {
				xtemp += dx; //otherwise, keep moving leftward
			}
		}
		if(dx > 0){
			if(topRight || bottomRight) {
				dx = 0; //stop moving rightward
				xtemp = (currCol+1)*tileSize - cwidth/2; //set the object just before that boundary
			} else {
				xtemp += dx; //otherwise, keep moving rightward
			} 
		}
		
		// check ground while moving on ground
		if(!falling) {
			calculateCorners(x, ydest+1);
			if(!bottomLeft && !bottomRight){
				falling=true; //if there's no ground below you while moving, then start falling
			}
		}
	}
	

	
	// only map the objects that are on the screen
	public boolean notOnScreen() {
		return x + xmap + width < 0
			|| x + xmap - width > GamePanel.WIDTH 
			|| y + ymap + height < 0
			|| y + ymap - height > GamePanel.HEIGHT;
	}
	
	
	
	// getters
	public double getx() {return x; }
	public double gety() {return y; }
	public int getWidth()   {return width;   }
	public int getHeight()  {return height;  }
	public int getCWidth()  {return cwidth;  }
	public int getCHeight() {return cheight; }
	
	// setters
	public void setPosition(double x, double y) {
		this.x = x;
		this.y = y;
	}
	public void setVector(double dx, double dy) {
		this.dx = dx;
		this.dy = dy;
	}
	public void setMapPosition() {
		xmap = tileMap.getx();
		ymap = tileMap.gety();
	}
	
	
	public void setLeft(boolean b)    { left = b;    }
	public void setRight(boolean b)   { right = b;   }
	public void setUp(boolean b)      { up = b;      }
	public void setDown(boolean b)    { down = b;    }
	public void setJumping(boolean b) { jumping = b; }
	public void setStrike(boolean b)  { lightningStrike = b; }
	public void setBoulderDropping(boolean b) { dropping = b; }
	
	
}
