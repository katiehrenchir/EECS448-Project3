package Entity;

import TileMap.*;
import Main.GamePanel;
import Entity.Boulder;


import java.util.ArrayList;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;



public class Storm extends MapObject {
	
	// storm variables
	private int health;
	private int maxHealth;
	private int healthDecrement;
	private boolean dead;
	private int maxDropped;
	
	private int collideTile;
	private boolean dropping;
 	private int boulders;
 	private int maxBoulders;
	private int dropped;
	
	
	private ArrayList<Boulder> BouldersArr;
	
	// storm animations 
	private ArrayList<BufferedImage[]> sprites;
	
	// num frames per animation 
	private final int[] numFrames = { 1, 1, 6, 1};
	
	// animation variables
	private static final int IDLE = 0;
	private static final int MOVING = 0; //for later animation of moving cloud
	private static final int LIGHTNING_CLOUD = 1;
	private static final int LIGHTNING_STRIKE = 2;
	private static final int WARNING = 3;
	private static final int BOULDER = 4;

	// off-screen warning info
	private boolean WARNING_LEFT;
	private boolean WARNING_RIGHT;
	
	
	public Storm(TileMap tm){
		super(tm);
		
		width = 64;
		height = 21;
		cwidth = 64;
		cheight = 21;
		
		moveSpeed = 0.15;
		maxSpeed = 3.0;
		stopSpeed = 0.10;
		
		maxBoulders = 10;
		
		BouldersArr = new ArrayList<Boulder>(10);
		//BouldersArr.size(10);
		dropped = 0;
		
		maxHealth = 100;
		maxDropped = 10;
		
		dead = false;
		
		try{
			BufferedImage spritesheet = ImageIO.read(
					getClass().getResourceAsStream( "/Sprites/storm_cloud.gif" )
			);
			
			
			sprites = new ArrayList<BufferedImage[]>();
			
			// read animations from spritesheet
			for(int i=0 ; i<4 ; i++) {
				BufferedImage[] bi = new BufferedImage[numFrames[i]];
				
				if(i==3){ width = 36;}
				else{ width = 64;}
				
				if(i==2) { 
					// height = 16
					for(int j=0 ; j<numFrames[i] ; j++){
						bi[j] = spritesheet.getSubimage(
								j * width, 
								i * height, 
								width, 
								16);
					}
				} 
				else {
					for(int j=0 ; j<numFrames[i] ; j++){
						bi[j] = spritesheet.getSubimage(
								j * width, 
								i * height, 
								width, 
								height);
					}
				}
				width = 64;
				
				sprites.add(bi);
			}
			 	
		} catch(Exception e) {e.printStackTrace(); }
			
		// storm cloud initialization:
		animation = new Animation();
		currentAction = IDLE;
		animation.setFrames(sprites.get(IDLE));
		animation.setDelay(100);
		
		strikeAnimation = new Animation();
		strikeAnimation.setFrames(sprites.get(LIGHTNING_STRIKE));
		strikeAnimation.setDelay(100);
		
		// off-screen warning initializationL
		warningAnimation = new Animation();
		warningAnimation.setFrames(sprites.get(WARNING));
		warningAnimation.setDelay(100);
		WARNING_LEFT = false;
		WARNING_RIGHT = false;
		
		
	}
		
	
	public void checkBump(ArrayList<Boulder> BouldersArr, Player player){
		for(int i=0 ; i<BouldersArr.size(); i++){
			player.intersects(BouldersArr.get(i));
		}
		checkTileMapCollision();
	}
	
	
	public void update() {
		// update position
		getNextPosition();
		checkTileMapCollision();
		setPosition(xtemp,ytemp);
		
		// movement control here
		if(left || right) {
			if(currentAction != MOVING) {
				previousAction = currentAction;
				currentAction = MOVING;
				animation.setFrames(sprites.get(MOVING));
				animation.setDelay(100);
			}
		}
		else if(lightningStrike){
			if(!notOnScreen()){
				if(currentAction != LIGHTNING_STRIKE){
					previousAction = currentAction;
					currentAction = LIGHTNING_STRIKE;
					animation.setFrames(sprites.get(LIGHTNING_CLOUD));
					collideTile = tileMap.getHighestTile( x, y );
				}
			}
		}
		else if(dropping){	
				dropped += 1;
				if(dropped > maxDropped){ dropped = maxDropped;}
				if(currentAction != BOULDER){
					previousAction = currentAction;
					currentAction = BOULDER;
					Boulder thisboulder = new Boulder(tileMap);
					thisboulder.setPosition(x,y);
					BouldersArr.add(thisboulder);
			}
		}
		else {
			if(currentAction != IDLE) {
				previousAction = currentAction;
				currentAction = IDLE;
				animation.setFrames(sprites.get(IDLE));
				animation.setDelay(100);
			}
		}
		
		
		// boulder drop
		for(int i=0 ; i < BouldersArr.size(); i++){
			BouldersArr.get(i).update();
			if(BouldersArr.get(i).shouldRemove()){
				BouldersArr.remove(i);
				i--;
			}
		}
		
		
		
		if (x+xmap+width-30 > GamePanel.WIDTH){ //exits right side of game panel
			WARNING_LEFT = false;
			WARNING_RIGHT = true;
		}
		else if(x+xmap+width-10 < 0){ //exits left side of game panel
			WARNING_LEFT = true;
			WARNING_RIGHT = false;
		}
		else {
			WARNING_LEFT = false;
			WARNING_RIGHT = false;
		}
		
		
		animation.update();
		warningAnimation.update();
		

	}
	
	public ArrayList<Boulder> getBouldersArr(){
		
		return BouldersArr ;
	}
	
	
	public void setBoulderDropping(boolean b) {
		dropping = b;
	}
	public int getDropped() { return dropped; } 
	
	
	public boolean isDead(){
		return dead;
	}
	
	public boolean getlightningStrike(){
		return lightningStrike;
	}
	
	private void getNextPosition() {
		// left and right
		if(left) {
			dx -= moveSpeed;
			if(dx < -maxSpeed) {
				dx = -maxSpeed;
			}
		} else if(right) {
			dx += moveSpeed;
			if(dx > maxSpeed) {
				dx = maxSpeed;
			}
		} else {
			if(dx > 0) {
				dx -= stopSpeed;
				if(dx <= 0) {
					dx = 0;
				}
			} else if (dx < 0) {
				dx += stopSpeed;
				if(dx > 0){
					dx = 0;
				}
			}
		}
	}	
	
	
	 	
	public void draw(Graphics2D g) {
		setMapPosition();

		
		//draw boulders:
		for(int i=0 ; i < BouldersArr.size() ; i++){
			BouldersArr.get(i).draw(g);
		}
		
		
		// draw storm
		g.drawImage( 
			animation.getImage(),
			(int)(x + xmap - width/2),
			(int)(y + ymap - height/2),
			null 
		);
		

		
		//draw lightning
		if(currentAction==LIGHTNING_STRIKE && previousAction!=LIGHTNING_STRIKE){
			if(collideTile != 0) {
				System.out.println("collidetile" + collideTile);
				int tempFrame = 0;
				for(int i=0 ; i<collideTile-5; i++){
					g.drawImage(
						strikeAnimation.getThisFrameImage(tempFrame),
						(int)(x + xmap - width/2),
						(int)(y + ymap + i*16 - height/2 + 21),
						null
					);
					tempFrame++;
					if(tempFrame>=6) {tempFrame=1;}
				}
			}
		}
		
		//draw warning
		if(WARNING_LEFT){
			g.drawImage(
				warningAnimation.getImage(),
				(int)(0),
				(int)(80),
				null
			);
		} else if(WARNING_RIGHT){
			g.drawImage(
				warningAnimation.getImage(),
				(int)(GamePanel.WIDTH - 36),
				(int)(80),
				null
			);
		}
		
		
		
		
		
		
		
	}
	
	
	
	
}