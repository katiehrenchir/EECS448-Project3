/**
 * Player class
 * 
 * edited/modified by: Mac Crider
 * 
 * 
 */


package Entity;

import Entity.Boulder;
import TileMap.*;
import Main.GamePanel;

import java.util.ArrayList;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;



public class Player extends MapObject {
	
	// player variables
	private int health;
	private int maxHealth;
	private int fire;
	private int maxFire;
	private boolean dead;
	private boolean flinching;
	private long flinchTimer;
	private boolean wheelie;
	private boolean duck;
	
	// animations
	private ArrayList<BufferedImage[]> sprites;
	
	//number of frames per animation
	private final int[] numFrames = { 3 , 6 , 1 };

	// animation actions
	private static final int IDLE =    0;
	private static final int DRIVING = 1;
	private static final int DUCKING = 2;
	private static final int JUMPING = 3;
//	private static final int BRAKING = 4;
//	private static final int FALLING = 5;
	
	
	public Player(TileMap tm){
		super(tm);
		
		width = 29;
		height = 20;
		cwidth = 25;
		cheight = 20;
		
		moveSpeed = 0.3;
		maxSpeed  = 3.0;
		stopSpeed = 0.15;
		fallSpeed = 0.3;
		maxFallSpeed = 6.0;
		jumpStart = -6.0;
		stopJumpSpeed = 0.15;
		facingRight = true;
		dead = false;
		
		try {
			BufferedImage spritesheet = ImageIO.read(
					getClass().getResourceAsStream( "/Sprites/DemmyMoto.gif" )
			);
			
			sprites = new ArrayList<BufferedImage[]>();
			
			// read animations from spritesheet
			for(int i=0 ; i<3 ; i++) {
				BufferedImage[] bi = new BufferedImage[numFrames[i]];
				
				if(i != 2){
					for(int j=0 ; j<numFrames[i] ; j++){
						bi[j] = spritesheet.getSubimage(
								j * width, 
								i * height, 
								width, 
								height);
					}
				} else {
					for(int j=0 ; j<numFrames[i] ; j++){
						bi[j] = spritesheet.getSubimage(
								j * width, 
								i * height, 
								width, 
								height);
					}
				}
				sprites.add(bi);
			}			
		} catch(Exception e) {e.printStackTrace(); }
		
		
		
		
		animation = new Animation();
		currentAction = IDLE;
		animation.setFrames(sprites.get(IDLE));
		animation.setDelay(100);
		height = 20;
		cheight = 20;
		
	}
	

	
	
	public void update() {
		//update position
		getNextPosition();
		checkTileMapCollision();
		setPosition(xtemp, ytemp);
		
		// set animation
/*		if(dy>0) {
			if(currentAction != JUMPING) {
				currentAction = JUMPING;
				animation.setFrames(sprites.get(JUMPING));
				animation.setDelay(100);
			}
		}
*/		
		
		
		if(down){
			if(currentAction != DUCKING){
				previousAction = currentAction;
				currentAction = DUCKING;
				animation.setFrames(sprites.get(DUCKING));
				animation.setDelay(100);
				cheight = 16;
			}
		}
		else if(left || right){
			if(currentAction != DRIVING){
				previousAction = currentAction;
				currentAction = DRIVING;
				animation.setFrames(sprites.get(DRIVING));
				animation.setDelay(100);
				cheight = 20;
			}
		}
		else {
			if(currentAction != IDLE) {
				previousAction = currentAction;
				currentAction = IDLE;
				animation.setFrames(sprites.get(IDLE));
				animation.setDelay(100);
				cheight = 20;
			}
		}
		
		if((previousAction == DUCKING) && (currentAction != DUCKING) && (!falling)) y = y - 2;
		if((previousAction != DUCKING) && (currentAction == DUCKING) && (!falling)) y = y + 2;
		previousAction = currentAction;
		
		animation.update();
		
		
		if(right) facingRight = true;
		if(left) facingRight = false;
	}
	
	
	public boolean isDead(){
		if(y > GamePanel.HEIGHT){
			dead = true;
		} 
		
		return dead;
	}
	
	public void setDead(boolean input){
		dead = input;
	}
	
	
	private void getNextPosition() {
		// left and right
		if(left) {
			dx -= moveSpeed;
			if(dx < -maxSpeed) {
				dx = -maxSpeed;
			}
		} else if(right) {
			dx += moveSpeed;
			if(dx > maxSpeed) {
				dx = maxSpeed;
			}
		} else {
			if(dx > 0) {
				dx -= stopSpeed;
				if(dx <= 0) {
					dx = 0;
				}
			} else if (dx < 0) {
				dx += stopSpeed;
				if(dx > 0){
					dx = 0;
				}
			}
		}
		
	/*	if(currentAction!=DUCKING && previousAction==DUCKING){
			dy -= 2;
		}
	*/	
		// jumping
		if(jumping && !falling){
			dy = jumpStart;
			// dx = 0;
			falling = true;
		}
		
		// falling 
		if(falling){
			dy += fallSpeed;
	
			if(dy<0) jumping = false;
			if(dy<0 && !jumping) dy += stopJumpSpeed;
			if(dy > maxFallSpeed) dy = maxFallSpeed;
		}
	}
	
	
	public void draw(Graphics2D g) {
		setMapPosition();
		
		// draw player
		if(currentAction==DUCKING) {
			// (ducking bug fix)
			if(facingRight) {
				g.drawImage( 
					animation.getImage(),
					(int)(x + xmap - width/2),
					(int)(y - 2 + ymap - height/2),
					null 
				);		
			} else {
				g.drawImage( 
					animation.getImage(), 
					(int)(x + xmap - width/2 + width), 
					(int)(y - 2 + ymap - height/2), 
					-width,
					height,
					null
				);
			}
		}else {
			if(facingRight) {
				g.drawImage( 
					animation.getImage(),
					(int)(x + xmap - width/2),
					(int)(y + ymap - height/2),
					null 
				);		
			} else {
				g.drawImage( 
					animation.getImage(), 
					(int)(x + xmap - width/2 + width), 
					(int)(y + ymap - height/2), 
					-width,
					height,
					null
				);
			}
		}
	}
	


	
	
	
	
}
