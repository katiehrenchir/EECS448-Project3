package Entity;

import java.util.ArrayList;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;

public class HUD {
	
	private Player player;
	private Storm storm;
	
	private BufferedImage image;
	private Font font;
	
	// off-screen warning info
	private boolean WARNING_LEFT;
	private boolean WARNING_RIGHT;
	
	public HUD(Player p, Storm s){
		player = p;
		storm = s;
		
	}
	
	
	public void draw(Graphics2D g) {
		g.drawImage(image,  0,  10,  null);
		g.setFont(font);
		
	}
}
