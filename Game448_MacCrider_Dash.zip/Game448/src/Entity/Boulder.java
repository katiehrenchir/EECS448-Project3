package Entity;

import Main.GamePanel;
import TileMap.TileMap;

import java.util.ArrayList;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;



public class Boulder extends MapObject {
	
	private boolean hit;
	private boolean remove;
	private BufferedImage[] sprites;
	private boolean falling;
	
	
	
	private static final int IDLE = 0;
	private static final int FALLING = 0;
	
	public Boulder(TileMap tm) {
		super(tm);
		
		fallSpeed = 0.3;
		maxFallSpeed = 6.0;
		falling = true;
		width = 16;
		height = 16;
		cwidth = 16;
		cheight = 16;
		
		try {
			BufferedImage spritesheet = ImageIO.read(
				getClass().getResourceAsStream("/Sprites/boulder.gif")	
			);
			
			sprites = new BufferedImage[1];
			sprites[0] = spritesheet.getSubimage(
						 0,
						 0,
						 width,
						 height);
			
		} catch(Exception e) { e.printStackTrace();}
		
		animation = new Animation();
		currentAction = FALLING;
		animation.setFrames(sprites);
		animation.setDelay(70);
		falling = true;
	}
	
	
	public boolean shouldRemove() {return remove;}
	public void getNextPosition(){
		
		
	}
	
	public void update() {
		//getNextPosition();
		
		
		if(falling){
			dy += fallSpeed;
			if(dy > maxFallSpeed) dy = maxFallSpeed;
		}else {
			//dy = 0;
		}

		
		checkTileMapCollision();
		setPosition(xtemp,ytemp);

		animation.update();
	}
	
	
	public void draw(Graphics2D g){
		setMapPosition();
		g.drawImage(
			animation.getImage(),
			(int)(x + xmap - width/2),
			(int)(y + ymap - height/2),
			null
		);
		
		
	}
	
}








