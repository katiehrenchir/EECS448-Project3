package GameState;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import GameState.GameStateManager;
import Main.GamePanel;
import TileMap.*;
import Entity.*;


public class Level1State extends GameState {
	
	private TileMap tileMap;
	private Background bg;
	
	private Player player;
	private Storm storm;
	
	private HUD hud;
	
	public Level1State(GameStateManager gsm) {
		this.gsm = gsm;
	
		init(); // initialize Level1
	}
	
	public void init() {
		// initiate and load foreground tiles
		tileMap = new TileMap(16);
		tileMap.loadTiles("/Tilesets/testGround.gif");
		tileMap.loadMap("/Maps/level1Map.txt");
		tileMap.setPosition(0, 0);
		tileMap.setBetween(0.15);		
		
		bg = new Background("/Backgrounds/menu_sunset_bg.png", 1);
	
		// initiate player:
		player = new Player(tileMap);
		player.setPosition(100,150);
		
		// initiate storm:
		storm = new Storm(tileMap);
		storm.setPosition(100,80);
		
		// initiate HUD:
		hud = new HUD(player,storm);
	
	}

	public void update() {
		// update player and storm
		player.update();
		storm.update();
		if( storm.getlightningStrike()){
			if((storm.getx() >= player.getx()-2) && (storm.getx() <= player.getx()+2)) {
				player.setDead(true);
			}
		}
		tileMap.setPosition(
				GamePanel.WIDTH / 2 - player.getx(),
				GamePanel.HEIGHT / 2 - player.gety()
		);
		
		bg.setPosition(tileMap.getx() / 2, tileMap.gety() / 2);
		
		
		
		if(player.isDead()){
			try {
				gsm.setState(GameStateManager.MENUSTATE);
			} catch (Exception e){
				e.printStackTrace();
			}
		}
		
	}
	
	
	public void draw(Graphics2D g) {
		// draw background:
		bg.draw(g);
		
		// draw tilemap
		tileMap.draw(g);
		
		checkBump( this.storm.getBouldersArr() , player);
		// draw player
		player.draw(g);
		
		// draw storm cloud
		storm.draw(g);
		
		
		
		// draw HUD
		hud.draw(g);
	}
	
	public void checkBump(ArrayList<Boulder> BouldersArr, Player player){
		for(int i=0 ; i<BouldersArr.size(); i++){
			this.player.intersects(BouldersArr.get(i));
		}
	}
	
	public void keyPressed(int k) {
		//player keys:
		if(k==KeyEvent.VK_LEFT)	 player.setLeft(true);
		if(k==KeyEvent.VK_RIGHT) player.setRight(true);
		if(k==KeyEvent.VK_UP)	 player.setUp(true);
		if(k==KeyEvent.VK_DOWN)	 player.setDown(true);
		if(k==KeyEvent.VK_SPACE) player.setJumping(true);
		
		//storm test keys:
		if(k==KeyEvent.VK_A)	 storm.setLeft(true);
		if(k==KeyEvent.VK_D)	 storm.setRight(true);
		if(k==KeyEvent.VK_S)	 storm.setStrike(true);
		if(k==KeyEvent.VK_W)	 storm.setBoulderDropping(true);
		if(k==KeyEvent.VK_ESCAPE) gsm.setState(GameStateManager.MENUSTATE);
	}
	
	public void keyReleased(int k) {
		if(k==KeyEvent.VK_LEFT)	 player.setLeft(false);
		if(k==KeyEvent.VK_RIGHT) player.setRight(false);
		if(k==KeyEvent.VK_UP)	 player.setUp(false);
		if(k==KeyEvent.VK_DOWN)	 player.setDown(false);
		if(k==KeyEvent.VK_SPACE) player.setJumping(false);
		
		//storm test keys:
		if(k==KeyEvent.VK_A)	 storm.setLeft(false);
		if(k==KeyEvent.VK_D)	 storm.setRight(false);
		if(k==KeyEvent.VK_S)	 storm.setStrike(false);
		if(k==KeyEvent.VK_W)	 storm.setBoulderDropping(false);
	}

}
