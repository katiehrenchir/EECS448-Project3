package MyAsistant;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

import eecs448.project.*;


public class MapHelp {
	
	public static void saveField(String name, Grid grid)
	{
		String Data = ""; //put the type of every single tile in a string
		for (int i = 0; i < grid.getSquarewidth(); i++)
		{
			for(int j = 0; j < grid.getSquareheight(); j++)
			{
				Data += getSquareID(grid.GetSquare(i, j));
			}
		}
		
		try
		{
			File file = new File(name); //write String Data to a file to save a map
			BufferedWriter w = new BufferedWriter(new FileWriter(file)); //this has to be put in a try and catch block
			w.write(Data);
			w.close();
		} 
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static SquareType getSquareType(String type)
	{
		SquareType st = SquareType.NULL;
		
		switch(type)
		{
			case "0":
				st = SquareType.Grass;
				break;
			case "1":
				st = SquareType.Road;
				break;
			case "2":
				st = SquareType.River;
				break;
			case "3":
				st = SquareType.NULL;
				break;
		}
		return st;
	}
	
	public static Grid loadField(String fieldID)
	{
		Grid grid = new Grid();
		
		try
		{
			BufferedReader r = new BufferedReader(new FileReader(fieldID));
			String Data = r.readLine();
			for(int i = 0; i < grid.getSquarewidth(); i++)
			{
				for(int j = 0; j < grid.getSquareheight(); j++)
				{
					grid.SetSquare(i, j, getSquareType(Data.substring(i * grid.getSquareheight() +j, i * grid.getSquareheight() + j + 1))); //start from x= 0, 
					//then y will be recorded until it reachese 15, then x=1 and start the second column
				}
				
			}
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
			
		
		return grid;
	}
	
	public static String getSquareID(Square s)
	{
		String ID = "W";
		
		switch(s.getType())
		{
		
			case Grass:
				ID = "0";
				break;
			case Road:
				ID = "1";
				break;
			case River:
				ID = "2";
				break;
			case NULL:
				ID = "3";
				break;
		}
		
		return ID;
	}

}
