package UserInterface;

import java.util.ArrayList;
import static MyAsistant.Asistant.*;

import org.lwjgl.input.Mouse;
import org.newdawn.slick.opengl.Texture;

public class UserInterface {

	private ArrayList<Icon> BList; //a list of clickable buttons
	
	public UserInterface()
	{
		BList = new ArrayList<Icon>();
	}
	
	public void CreateIcon(String name, String Tname, int x, int y)
	{
		BList.add(new Icon(name, Fload(Tname), x, y));
	}
	
	public boolean isClicked(String IconName)
	{
		Icon I = getIcon(IconName);
		float mouseY = HEIGHT - Mouse.getY() -1;
		if(Mouse.getX() > I.getX() && Mouse.getX() < I.getX() + I.getWidth() && mouseY > I.getY() && mouseY < I.getY() + I.getHeight())
		{
			return true;
		}
		return false;
	}
	
	private Icon getIcon(String IconName)
	{
		for(Icon I: BList)
		{
			if (I.getName().equals(IconName))
			{
				return I;
			}
		}
		return null;
	}
	
	public void Draw()
	{
		for(Icon I: BList)
		{
			DrawSquareTex(I.getTex(), I.getX(), I.getY(), I.getWidth(), I.getHeight());
		}
	}
}
