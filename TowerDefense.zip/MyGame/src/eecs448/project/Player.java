/**
* @author Yehan Li
* @file main.cpp
* @since 30 October 2016
* @brief A Tower Defense Program.
* Watched tutorials that helped me from the flowing websites:
* 
* https://www.youtube.com/watch?v=H3Dn1CQsREw
* https://www.youtube.com/watch?v=Euiqdd09n68
* https://www.youtube.com/watch?v=7QDz81jMsF8
* https://www.youtube.com/watch?v=uwp-xW0kylc&t=5s
* https://www.youtube.com/watch?v=qoi6ASLK7iI
* https://www.youtube.com/watch?v=0v56I5UWrYY&list=PL19F2453814E0E315
*/
package eecs448.project;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import MyAsistant.Time;

import static MyAsistant.Asistant.*;

import java.util.ArrayList;

public class Player {
	
	private Grid g;
	private SquareType[] t;
	private int marker;
	private GroupControl groupControl;
	private ArrayList<Rocket> TList;
	boolean clickOnce;
	private int count;
	
	/**
	 * the constructor a player
	 * @param g A Grid
	 */
	public Player(Grid g, GroupControl groupControl)
	{
		this.g = g;
		this.t = new SquareType[3];
		this.t[0] = SquareType.Grass;
		this.t[1] = SquareType.River;
		this.t[2] = SquareType.Road;
		this.groupControl = groupControl;
		this.TList = new ArrayList<Rocket>();
		this.marker = 0;
		this.clickOnce = false;
	}
	
	
	/**
	 * Detect clicks
	 */
	public void update()
	{
		for(Rocket r: TList)
		{
			r.update();
			r.updateMonsterList(groupControl.getCurrentGroup().getMonsterList());
		}
		
		if(Mouse.isButtonDown(0)&& !clickOnce && count <10)//0 = left click, 1= right click Mouse interaction
		{
			TList.add(new Rocket(Fload("rocket"), g.GetSquare(Mouse.getX() / 64, (HEIGHT - Mouse.getY() - 1)/64), 10, 1000, groupControl.getCurrentGroup().getMonsterList()));
			count++;
		}
		clickOnce = Mouse.isButtonDown(0);
		
		while(Keyboard.next())// Keyboard interaction between players and the game
		{
			if(Keyboard.getEventKey() == Keyboard.KEY_U && Keyboard.getEventKeyState())
			{
				Time.setTimes(0.2f);
			}
			
			if(Keyboard.getEventKey() == Keyboard.KEY_D && Keyboard.getEventKeyState())
			{
				Time.setTimes(-0.2f);
			}
			
			if(Keyboard.getEventKey() == Keyboard.KEY_T && Keyboard.getEventKeyState())
			{
				//TList.add(new Rocket(Fload("rocket"), g.GetSquare(17, 8), 10, 1000, groupControl.getCurrentGroup().getMonsterList()));
			}
		}
	}
	
	

	
	
}
