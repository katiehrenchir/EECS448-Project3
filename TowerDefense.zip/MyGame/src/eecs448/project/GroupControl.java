package eecs448.project;

import static MyAsistant.Asistant.*;

import org.newdawn.slick.opengl.Texture;

public class GroupControl {
	
	private float groupDelta, spawnTime; // the time interval between the spawn of monster groups
	private int groupNum, mPerGroup; 
	private Monster m;
	private Group rightNowGroup;
	private int count = 0;
	
	
	public GroupControl(Monster m, float spawnTime, int mPerGroup)
	{
		this.m = m;
		this.spawnTime = spawnTime;
		this.mPerGroup = mPerGroup;
		this.groupDelta = 0;
		this.groupNum = 0;
		this.rightNowGroup = null;
		newGroup();
	}
	
	public void update()
	{
		if(!rightNowGroup.groupEnd())
			rightNowGroup.update();
		else if(count>=5)
			DrawSquareTex(Fload("over"), 0, 0, 2048, 1024);
		else
		{
			newGroup();
			count ++;
		}
	}

	
	private void newGroup()
	{
		rightNowGroup = new Group(m, spawnTime, mPerGroup);
		groupNum++;
	}
	
	public Group getCurrentGroup()
	{
		return rightNowGroup;
	}
}
