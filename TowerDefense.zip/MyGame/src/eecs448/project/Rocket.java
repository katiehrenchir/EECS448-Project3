package eecs448.project;

import static MyAsistant.Asistant.*;
import static MyAsistant.Time.*;
import java.util.ArrayList;
import org.newdawn.slick.opengl.Texture;

public class Rocket {
	
	private float x, y, delta, fireInterval, degree; //delta is the time interval between each shot
	private int width, height, dam, area; // area is just simply the radius of the tower detecting area
	private Texture texR, texB; // the texture of the Rocket and its background
	private Square start;
	private ArrayList<Parabola> bullets;
	private ArrayList<Monster> m;
	private Monster focusMonster;
	private boolean isAiming;
	
	public Rocket(Texture texR, Square start, int dam, int area, ArrayList<Monster> m)
	{
		this.texR = texR;
		this.texB = Fload("rocket");
		this.start = start;
		this.x = start.getX();
		this.y = start.getY();
		this.width = (int) start.getWidth();
		this.height = (int) start.getHeight();
		this.dam = dam;
		this.m = m;
		this.area = area;
		this.fireInterval = 1;
		this.delta = 0;
		this.isAiming = false;
		this.bullets = new ArrayList<Parabola>();
		//this.focusMonster = getfocusMonster();
		//this.degree = measureDegree();
	}
	
	private boolean InArea(Monster m)
	{
		float xco = Math.abs(m.getX() - x);
		float yco = Math.abs(m.getY() - y);
		if(xco < area && yco < area)
			return true;
		return false;
	}
	
	private float measureDistance(Monster m)
	{
		float xco = Math.abs(m.getX() - x);
		float yco = Math.abs(m.getY() - y);
		return xco +yco;
	}
	
	private Monster getfocusMonster()
	{
		Monster betterTarget = null;
		float distance = 10000;
		for(Monster mon: m)//mon is one of the monsters in the m monster list
		{
			if(InArea(mon) && measureDistance(mon) < distance && mon.getHp2() > 0)//when find a monster that is closer, aim that enemy
				distance = measureDistance(mon); //set the distance between the monster and the tower
				betterTarget = mon;
		}
		
		if(betterTarget != null)
			isAiming = true;
	 
		
		return betterTarget;
	}
	
	
	private float measureDegree()
	{
		double testAngle = Math.atan2(focusMonster.getY()- y, focusMonster.getX()- x); //x, y are the position of the Tower
		return (float)Math.toDegrees(testAngle);
	}
	
	public void update()
	{
		if(!isAiming)
		{
			focusMonster = getfocusMonster();
		}
		
		if(focusMonster == null || focusMonster.isAlive() == false) //if monster reaches the end or died, find another monster to aim
		{
			isAiming = false;
			
		}
		
		delta += Delta();
		if(delta > fireInterval)
			Fire();
		for(Parabola p: bullets)
			p.update();
		
		 degree = measureDegree();
		
		 Draw();
	}
	
	private void Fire()
	{
		delta = 0;
		bullets.add(new Parabola(Fload("bullet"), focusMonster, x + Play.SQUARE_SIZE/4, y + Play.SQUARE_SIZE/4, 32, 32, 3000, 10));
		focusMonster.minusHp2(10);
	}
	
	public void Draw()
	{
		DrawSquareTex(texB, x, y, width, height);
		DrawSquareTexRot(texR, x, y, width, height, degree);
	}
	
	public void updateMonsterList(ArrayList<Monster> ml)
	{
		m = ml;
	}
}
