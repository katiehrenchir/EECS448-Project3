package eecs448.project;

import org.lwjgl.input.Mouse;
import org.newdawn.slick.opengl.Texture;

import MyAsistant.StateControl;
import MyAsistant.StateControl.GameControl;
import UserInterface.UserInterface;

import static MyAsistant.Asistant.*;

public class Menu {

	private Texture backimage;
	private UserInterface UI;
	
	public Menu()
	{
		backimage = Fload("menu");
		UI = new UserInterface();
		UI.CreateIcon("Play", "play", WIDTH/2 - 128, (int)(HEIGHT*0.45f));
		UI.CreateIcon("Edit", "edit", WIDTH/2 - 128, (int)(HEIGHT*0.55f));
		UI.CreateIcon("Load", "load", WIDTH/2 - 128, (int)(HEIGHT*0.65f));
		UI.CreateIcon("Quit", "quit", WIDTH/2 - 128, (int)(HEIGHT*0.75f));
	}
	
	public void update()
	{
		DrawSquareTex(backimage, 0, 0, 2048, 1024);
		UI.Draw();
		updateIcons();
	}
	
	private void updateIcons()
	{
		if (Mouse.isButtonDown(0)) 
		{
			if(UI.isClicked("Play"))
			{
				StateControl.setState(GameControl.PLAY);
			}
			
			if(UI.isClicked("Edit"))
			{
				StateControl.setState(GameControl.EDIT);
			}
			
			if(UI.isClicked("Load"))
			{
				StateControl.setState(GameControl.LOAD);
			}
			
			
			if(UI.isClicked("Quit"))
			{
				System.exit(0) ;
			}
		}
	}
	
}
