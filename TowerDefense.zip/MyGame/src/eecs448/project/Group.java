/**
* @author Yehan Li
* @file main.cpp
* @since 30 October 2016
* @brief A Tower Defense Program.
* Watched tutorials that helped me from the flowing websites:
* 
* https://www.youtube.com/watch?v=H3Dn1CQsREw
* https://www.youtube.com/watch?v=Euiqdd09n68
* https://www.youtube.com/watch?v=7QDz81jMsF8
* https://www.youtube.com/watch?v=uwp-xW0kylc&t=5s
* https://www.youtube.com/watch?v=qoi6ASLK7iI
* https://www.youtube.com/watch?v=0v56I5UWrYY&list=PL19F2453814E0E315
*/
package eecs448.project;

import java.util.ArrayList;
import static MyAsistant.Time.*;

public class Group {

	private float lSpawn, SpawnT;
	private Monster t;
	private ArrayList<Monster> Mlist;
	private int mPerGroup;
	private boolean groupEnd;
	
	/**
	 * 
	 * @param SpawnT Spawn Time 
	 * @param t a monster
	 */
	public Group(Monster t, float SpawnT, int mPerGroup)
	{
		this.t = t; //this means the variables of this class(private)
		this.SpawnT = SpawnT;
		this.mPerGroup = mPerGroup;
		this.lSpawn = 0;
		this.Mlist = new ArrayList<Monster>();
		this.groupEnd = false;
		Spawn();
	}
	
	/**
	 * Populate the monster group and show it on the window
	 */
	public void update()
	{
		boolean allMonDied = true;
		if(Mlist.size()< mPerGroup) // check if the monsters in this wave is enough, if not, keep spawning monsters
		{
			lSpawn += Delta();
			if(lSpawn > SpawnT)
			{
				Spawn();
				lSpawn = 0;
			}
		}
		
		for (Monster m: Mlist)
		{
			if(m.isAlive())
			{
				allMonDied = false;
				m.update();
				m.Draw();
			}
		}
		
		if(allMonDied)
			groupEnd = true;
			
	}
	
	/**
	 * Spawn a Monster
	 */
	public void Spawn()
	{
		Mlist.add(new Monster(t.getTex(), t.getGrid(), t.getS(), 64, 64, t.getSpeed(), t.getHp()));
	}
	
	public Monster getMonster()
	{
		return t;
	}
	
	public boolean groupEnd()
	{
		return groupEnd;
	}
	
	public ArrayList<Monster> getMonsterList()
	{
		return Mlist;
	}
}
