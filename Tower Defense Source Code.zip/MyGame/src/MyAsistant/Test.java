package MyAsistant;
//import static MyAsistant.Asistant.*;
//import org.newdawn.slick.opengl.Texture;

import eecs448.project.*;
public class Test {
	
	private GroupControl g = new GroupControl();
	private Rocket r = new Rocket();
	private Player p = new Player();
	private Grid gr = new Grid(23, 15);
	
	/**
	 * The constructor of text class
	 */
	public Test()
	{
	}
	
	/**
	 * call all text functions
	 */
	public void Test1()
	{
		TestOver();
		TestAiming();
		TestAiming2();
		LimitTest();
		LimitTest2();
		SquareTest();
		MapTest();
	}
	
	/**
	 * test if the game will end after 5 rounds
	 */
	public void TestOver()
	{
		for(int i = 0; i < 5; i ++)
		{
			g.waveCount();
		}
		
		if(g.isOver())
			System.out.println("1. The Game ends after 5 waves of monster are spawned(Correct)");
		else
			System.out.println("1. The Game doesn't end after 5 waves of monster are spawned(Wrong)");
	}
	
	/**
	 * test the aiming ability of towers
	 */
	public void TestAiming()
	{
		if(r.TestAim())
			System.out.println("2. Towers are aiming at somthing when there are no monsters on the Map(Wrong)");
		else
			System.out.println("2. Towers are aiming at nothing when there are no monsters on the Map(Correct)");
	}
	
	/**
	 *  test the stability of aiming
	 */
	public void TestAiming2()
	{
		if(r.Aiming())
			System.out.println("3. Towers are aiming at monsters when there are monsters on the Map(Correct)");
		else
			System.out.println("3. Towers are not aiming at monsters when there are monsters on the Map(Wrong)");
	}
	
	/**
	 * test the rules of games
	 */
	public void LimitTest()
	{
		for(int i = 0; i < 10; i ++)
		{
			p.marker();
		}
		if(p.TestLimit() <= 10)
			System.out.println("4. Players are unable to deploy towers when there are more than 10 towers on the map(Correct)");
		else if(p.TestLimit() > 10)		
			System.out.println("4. Players are able to deploy towers when there are more than 10 towers on the map(Wrong)");
	}
	
	/**
	 * test the rules of games
	 */
	public void LimitTest2()
	{
		for(int i = 0; i < 8; i ++)
		{
			p.marker();
		}
		if(p.TestLimit() > 10)
			System.out.println("5. Players are able to deploy towers when there are less than 10 towers on the map(Correct)");
		else if(p.TestLimit() <= 10 )		
			System.out.println("5. Players are able to deploy towers when there are more than 10 towers on the map(Wrong)");
	}
	
	/**
	 * test map loading function
	 */
	public void SquareTest()
	{
		System.out.print("6. ");
		TestSquare("0");
		System.out.print("7. ");
		TestSquare("1");
		System.out.print("8. ");
		TestSquare("2");
		System.out.print("9. ");
		TestSquare("3");
	}
	
	/**
	 * a copy of texturte detecting fucntion
	 * @param type name of the texture
	 * @return square texture
	 */
	public SquareType TestSquare(String type)
	{
		SquareType st = SquareType.NULL;
		String s;
				switch(type)
				{
					case "0":
						st = SquareType.Grass;
						s = "grass";
						System.out.println("Successfully set SquareType to "+s+" when the square index is "+ type );
						break;
					case "1":
						st = SquareType.Road;
						s = "road";
						System.out.println("Successfully set SquareType to "+s+" when the square index is "+ type );
						break;
					case "2":
						st = SquareType.River;
						s = "river";
						System.out.println("Successfully set SquareType to "+s+" when the square index is "+ type );
						break;
					case "3":
						st = SquareType.NULL;
						s = "nothing";
						System.out.println("Successfully set SquareType to "+s+" when the square index is "+ type );
						break;
				}
				return st;
	}
	
	/**
	 * test the number of squares on the map
	 */
	public void MapTest()
	{
		int sum = 23*15;
		if(gr.getSize() == sum)
			System.out.println("10. The Map contains "+sum+" Squares when load the designed 2D array(Correct)");
		else
			System.out.println("10. The map doesn't contain enough Squares when load the designed 2D array(Wrong)");
	}
	

}
