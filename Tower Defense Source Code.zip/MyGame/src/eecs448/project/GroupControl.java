package eecs448.project;

import static MyAsistant.Asistant.*;

import org.newdawn.slick.opengl.Texture;

public class GroupControl {
	
	private float groupDelta, spawnTime; // the time interval between the spawn of monster groups
	private int groupNum, mPerGroup; 
	private Monster m;
	private Group rightNowGroup;
	private int count = 0;
	private boolean isOver = false;
	
	/**
	 * the constructor of GroupControl Class
	 * @param m a monster
	 * @param spawnTime spawn time
	 * @param mPerGroup the number of monsters in a group
	 */
	public GroupControl(Monster m, float spawnTime, int mPerGroup)
	{
		this.m = m;
		this.spawnTime = spawnTime;
		this.mPerGroup = mPerGroup;
		this.groupDelta = 0;
		this.groupNum = 0;
		this.rightNowGroup = null;
		newGroup();
	}
	
	/**
	 * the second constructor of GroupControl Class
	 */
	public GroupControl()
	{
		
	}
	
	/**
	 * update groups of monsters
	 */
	public void update()
	{
		if(!rightNowGroup.groupEnd())
			rightNowGroup.update();
		else if(count>=5)
		{
			DrawSquareTex(Fload("over"), 0, 0, 2048, 1024);
		}
		else
		{
			newGroup();
			count ++;
		}
	}
	
	/**
	 * count wave numbers
	 */
	public void waveCount()
	{
		count++;
		if(count>=5)
		isOver = true;
	}
	
	/**
	 * detect if the game is over
	 * @return true/false
	 */
	public boolean isOver()
	{
		return isOver;
	}

	/**
	 * spawn a new group of monsters
	 */
	private void newGroup()
	{
		rightNowGroup = new Group(m, spawnTime, mPerGroup);
		groupNum++;
	}
	
	/**
	 * get the current groups of monsters
	 * @return a group of monster
	 */
	public Group getCurrentGroup()
	{
		return rightNowGroup;
	}
}
