/**
* @author Yehan Li
* @file main.cpp
* @since 30 October 2016
* @brief A Tower Defense Program.
* Watched tutorials that helped me from the flowing websites:
* 
* https://www.youtube.com/watch?v=H3Dn1CQsREw
* https://www.youtube.com/watch?v=Euiqdd09n68
* https://www.youtube.com/watch?v=7QDz81jMsF8
* https://www.youtube.com/watch?v=uwp-xW0kylc&t=5s
* https://www.youtube.com/watch?v=qoi6ASLK7iI
* https://www.youtube.com/watch?v=0v56I5UWrYY&list=PL19F2453814E0E315
*/
package eecs448.project;

import static MyAsistant.Asistant.*;
import static org.lwjgl.opengl.GL11.GL_LINES;
import static org.lwjgl.opengl.GL11.glBegin;
import static org.lwjgl.opengl.GL11.glEnd;
import static org.lwjgl.opengl.GL11.glVertex2f;

import org.lwjgl.opengl.Display;
import org.newdawn.slick.opengl.Texture;

import MyAsistant.StateControl;
import MyAsistant.Test;
import MyAsistant.Time;
/**
 * This is the main class to run this game
 * @author Yehan Li
 *
 */
public class Main 
{	
	private static Test t = new Test();
	
	public Main()
	{
		View();
		//Play play = new Play(field);
		while(!Display.isCloseRequested())
		{
			Time.update();
			//play.update();
			StateControl.update();
			Display.update();//update the window/frame
			Display.sync(60);//set the fps
		}
		Display.destroy();
	}
	/**
	 * This Called Main function in it
	 * @param arg
	 */
	public static void main(String arg[])
	{
		t.Test1();
		new Main();
	}
}
 