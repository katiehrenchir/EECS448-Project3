package eecs448.project;

import static MyAsistant.Asistant.*;
import static MyAsistant.MapHelp.*;
import static MyAsistant.Asistant.HEIGHT;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import MyAsistant.Time;

public class Editor {
	
	private Grid grid;
	private int marker;
	private SquareType[] t;
	
	/**
	 * the constructor of Editor class
	 */
	public Editor()
	{
		this.grid = new Grid();
		//this.grid = loadField("map");
		this.marker = 0;
		this.t = new SquareType[3];
		this.t[0] = SquareType.Grass;
		this.t[1] = SquareType.River;
		this.t[2] = SquareType.Road;
	}
	
	/**
	 * update the customized map
	 */
	public void update()
	{
		grid.Draw();

		if(Mouse.isButtonDown(0))//0 = left click, 1= right click Mouse interaction
		{
			setSquare();

		}
	
		while(Keyboard.next())// Keyboard interaction between players and the game
		{
			if(Keyboard.getEventKey() == Keyboard.KEY_C && Keyboard.getEventKeyState())
			{
				ChangeMarker();
			}
			
			if(Keyboard.getEventKey() == Keyboard.KEY_R && Keyboard.getEventKeyState()) //KEY_ follows the key that you want to use on the keyboard
			{
				saveField("map", grid);
			}
			
		
		}
	}
	
	/**
	 * Set a square to a type
	 */
	private void setSquare()
	{
		grid.SetSquare((int)Math.floor(Mouse.getX() / 64), (int)Math.floor((HEIGHT - Mouse.getY() - 1)/64), t[marker]);
	}
	
	/**
	 * Change the marker of square types in an order
	 * marker is the indicator of the array size of squaretype
	 */
	public void ChangeMarker()
	{
		marker = marker +1;
		if(marker > t.length - 1)
		{
			marker = 0;
		}
	}
}
