package eecs448.project;

import org.newdawn.slick.opengl.Texture;
import static MyAsistant.Time.*;
import static MyAsistant.Asistant.*;

public class Parabola {

	private boolean living;
	private Texture tex;
	private float x, y, speed, xSpeed, ySpeed, width, height;
	private int dam;
	private Monster m;
	
	/**
	 * the constructor of Parabola class
	 * @param tex texture of bullets
	 * @param m a monster being attacked
	 * @param x x position
	 * @param y y position
	 * @param width width
	 * @param height height
	 * @param speed speed of bullets
	 * @param dam damage points
	 */
	public Parabola(Texture tex, Monster m, float x, float y, float width, float height, float speed, int dam)
	{
		this.living = true;
		this.x = x;
		this.y = y;
		this.tex = tex;
		this.speed = speed;
		this.dam = dam;
		this.m = m;
		this.xSpeed = 0f;
		this.ySpeed = 0f;
		this.width = width;
		this.height = height;
		AimMonster();
	}
	
	/**
	 * aim a monster
	 */
	private void AimMonster()
	{
		float TotalMovement = 1.0f; //x and y movement of the bullet together are 1
		float xFromMonster = Math.abs(m.getX() - x + Play.SQUARE_SIZE/4); //make what is inside of the paranthesis an absolute value
		float yFromMonster = Math.abs(m.getY() - y + Play.SQUARE_SIZE/4); // plus 32 makes the aim of the rocket towards the center of the Square that the target monster is on
		float DistanceFromMonster = xFromMonster + yFromMonster;
		float xPortion = xFromMonster / DistanceFromMonster; // How many percent of TotalMovement is occupied by xMovement
		xSpeed = xPortion;
		ySpeed = TotalMovement - xPortion;
		if(m.getX() < x)
			xSpeed *= -1; //xSpeed = xSpeed * -1
		if(m.getY() < y)
			ySpeed *= -1;
		
	}
	
	/**
	 * update bullets being fired 
	 */
	public void update()
	{
		if(living && m.isAlive())
		{
			x += xSpeed * speed * Delta();
			y += ySpeed * speed * Delta();
			if(Overlap(x, y, width, height, m.getX(), m.getY(), m.getWidth(), m.getHeight()))
			{
				m.Hurt(dam);
				living = false;
			}
			Draw();
		}
	}
	
	/**
	 * draw bullets
	 */
	public void Draw()
	{
		DrawSquareTex(tex, x, y, 32, 32);
	}
}
