package eecs448.project;

import static MyAsistant.Asistant.*;
import static MyAsistant.MapHelp.*;

public class Play {
	
	private Grid g;
	private Player p;
	private GroupControl groupControl;
	public static final int SQUARE_SIZE = 64;
	
/**
 * the Constructor of play class
 * @param field the map
 */
	public Play(int[][] field) 
	{
		g = new Grid(field);
		groupControl = new GroupControl(new Monster(Fload("monster"), g, g.GetSquare(10,9), 64, 64, 100, 1000), 6, 2);//spawn time is in seconds
		p = new Player(g, groupControl);
	}
	
	/**
	 * the second constructor of play class
	 */
	public Play() 
	{
		g = loadField("map");
		groupControl = new GroupControl(new Monster(Fload("monster"), g, g.GetSquare(10,9), 64, 64, 100, 1000), 6, 2);//spawn time is in seconds
		p = new Player(g, groupControl);
	}
	
	/**
	 * update groups of monsters
	 */
	public void update()
	{
		
		g.Draw();
		p.update();
		groupControl.update();
		
	}
	
}
