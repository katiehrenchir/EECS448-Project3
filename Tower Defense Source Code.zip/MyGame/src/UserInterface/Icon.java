package UserInterface;

import org.newdawn.slick.opengl.Texture;

public class Icon {
	
	private Texture tex;
	private int x, y, width, height;
	private String name;
	
	/**
	 * first constructor
	 * @param name Icon name
	 * @param tex Icon texture
	 * @param x x position
	 * @param y y position
	 * @param width width
	 * @param height height
	 */
	public Icon(String name, Texture tex, int x, int y, int width, int height)
	{
		this.tex = tex;
		this.x = x;
		this. y = y; // x, y indicates the position to put the button/Icon
		this.width = width;
		this.height = height;
		this.name = name;
	}
	
	/**
	 * second constructor
	 * @param name Icon name
	 * @param tex texture
	 * @param x x position
	 * @param y y position
	 */
	public Icon(String name, Texture tex, int x, int y)
	{
		this.tex = tex;
		this.x = x;
		this. y = y;
		this.name = name;
		this.width = tex.getImageWidth();;
		this.height = tex.getImageHeight();
	}

	public Texture getTex() {
		return tex;
	}

	public void setTex(Texture tex) {
		this.tex = tex;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
