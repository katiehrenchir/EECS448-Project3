/*
* @author Yehan Li
* @file main.cpp
* @since 30 October 2016
* @brief A Tower Defense Program.
* Watched tutorials that helped me from the flowing websites:
* 
* https://www.youtube.com/watch?v=H3Dn1CQsREw
* https://www.youtube.com/watch?v=Euiqdd09n68
* https://www.youtube.com/watch?v=7QDz81jMsF8
* https://www.youtube.com/watch?v=uwp-xW0kylc&t=5s
* https://www.youtube.com/watch?v=qoi6ASLK7iI
* https://www.youtube.com/watch?v=0v56I5UWrYY&list=PL19F2453814E0E315
*/
package MyAsistant;

import org.lwjgl.Sys;

public class Time {
	
	private static boolean pause = false;
	public static long lframe , ttime;
	public static float d = 0, times = 1;
	/**
	 * Return the current time in milliseconds/ 1s= 1000ms convert from ticks to millisecond
	 * @return
	 */
	public static long getTime()
	{
		return Sys.getTime() * 1000/ Sys.getTimerResolution(); //in milliseconds/ 1s= 1000ms convert from ticks to millisecond
		//Sys.getTimerResolution() gives the number of ticks in a second////// Sys.getTime() gives you the current System time in ticks.
	}
	
	/**
	 * time between last frame time and right now
	 * @return
	 */
	public static float getDelta()
	{
		long currentTime = getTime();// current time(System time in ticks)
		int delta = (int) (currentTime - lframe);// time between last frame time and right now;
		lframe = getTime();
		return delta * 0.01f;
	}
	
	/**
	 * Return Delta Time
	 * @return
	 */
	public static float Delta()
	{
		if(pause)
			return 0;
		else
			return d*times;
	}

	/**
	 * Get Total Time
	 * @return
	 */
	public static float getTtime()
	{
		return ttime;
	}
	/**
	 * Return Times
	 * @return
	 */
	public static float getTimes()
	{
		return times;
	}
	/**
	 * Update Current Time
	 */
	public static void update()
	{
		d = getDelta();
		ttime+= d;
	}
	
	/**
	 * Set Times
	 * @param c
	 */
	public static void setTimes(int c)
	{
		if(times + times < -1 && times + times > 7)
		{
		}
		else
		{
			times += times;
		}
	}
	
	/**
	 * Pause
	 */
	public static void pause()
	{
		if(pause)
		{
			pause = false;
		}
		else
		{
			pause = true;
		}
	}
}
