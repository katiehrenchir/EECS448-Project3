/*
* @author Yehan Li
* @file main.cpp
* @since 30 October 2016
* @brief A Tower Defense Program.
* Watched tutorials that helped me from the flowing websites:
* 
* https://www.youtube.com/watch?v=H3Dn1CQsREw
* https://www.youtube.com/watch?v=Euiqdd09n68
* https://www.youtube.com/watch?v=7QDz81jMsF8
* https://www.youtube.com/watch?v=uwp-xW0kylc&t=5s
* https://www.youtube.com/watch?v=qoi6ASLK7iI
* https://www.youtube.com/watch?v=0v56I5UWrYY&list=PL19F2453814E0E315
*/
package eecs448.project;

import org.newdawn.slick.opengl.Texture;
import static MyAsistant.Time.*;

import java.util.ArrayList;

import static MyAsistant.Asistant.*;

public class Monster {
	private int width, height, hp, rightnowcorner;
	private float x, y, speed;
	private Grid g;
	private ArrayList<ChangeDirection> Corner; //corner literally means corner of the pathway
	private int[] GPS;
	private Texture tex;
	private Square s;
	private boolean wait = true;
	/**
	 * Variables to define the attributes of a monster(Constructor)
	 * @param tex texture
	 * @param g Grid
	 * @param s Beginning place of a monster
	 * @param width width of a monster
	 * @param height height of a monster
	 * @param speed speed if a monster
	 */
	public Monster(Texture tex, Grid g, Square s, int width, int height, float speed)
	{
		this.Corner = new ArrayList<ChangeDirection>();
		this.GPS = new int[2];
		this.GPS[0] = 0;// horizontal movement
		this.GPS[1] = 1;// vertical movement
		this.tex = tex;
		this.rightnowcorner = 0;
		this.x = s.getX();
		this.y = s.getY();
		this.width = width;
		this.height = height;
		this.speed = speed;
		this.g = g;
		this.s = s;
		GPS = Navigate(s);
		FillList();
	}
	/**
	 * Return a whether the monster passed the corner or not
	 * @return
	 */
	private boolean isOnNextStep()
	{
		boolean on = false;
		Square s = Corner.get(rightnowcorner).getTurn();
		if(x > s.getX() - 3 && x < s.getX() +3 && y > s.getY() - 3 && y< s.getY() +3)
		// we have a range of 3 for mistake to happen, the monster might not perfectly match the square. We allow mistake to happen
		{
			x = s.getX();
			y = s.getY();
			on = true;
			
		}
		return on;
	}
	/**
	 * Create a list of corners
	 */
	private void FillList()
	{
		Corner.add(NextCorner(s, GPS = Navigate(s)));
		int num = 0;
		boolean go = true;
		
		while(go)
		{
			int[] rightnowdir = Navigate(Corner.get(num).getTurn());
			if(rightnowdir[0] == 2 || num == 40)
				//we at most save 40 steps for monsters to go, the monster will check all four directions to see where they should go
			{
				go = false;
				System.out.println("Fill list reached the end!");
				
			}
			else
			{
				Corner.add(NextCorner(Corner.get(num).getTurn(), GPS = Navigate( Corner.get(num).getTurn()))); // if there is still a path to go, then keep adding next corner, else, we recorded all corners.
				System.out.println("we have "+ num + "steps in Arraylist");
			}
			num++;
		}
		
	}
	/**
	 * Finding the next corner and return the corner square back with the next moving direction
	 * @param at
	 * @param GPS
	 * @return
	 */
	private ChangeDirection NextCorner(Square at, int[] GPS)//finding the next corner and return the corner square back
	{
		int num =1;
		Square turn = null;
		ChangeDirection direction = null;
		boolean got = false;
		
		while(!got)
		{
			if(at.getType() != g.GetSquare(at.getIX() + GPS[0] * num, at.getIY() + GPS[1] * num).getType())
			{
				num= num-1;
				turn = g.GetSquare(at.getIX() + GPS[0] * num, at.getIY() + GPS[1] * num);
				got = true; 
			}
			num = num +1;
		}
		direction = new ChangeDirection(turn, GPS[0], GPS[1]);
		return direction;
	}

	/**
	 * Find where to go if the monster faces a different square other than the road squares
	 * @param at
	 * @return
	 */
	private int[] Navigate(Square at)
	{
		int[] nav = new int[2];
		Square up = g.GetSquare(at.getIX(), at.getIY() - 1);//we want to move up, not stay in the same place/Square
		Square down =  g.GetSquare(at.getIX(), at.getIY() + 1);
		Square left = g.GetSquare(at.getIX()-1, at.getIY());
		Square right = g.GetSquare(at.getIX() + 1, at.getIY());
		if(at.getType() == up.getType() && GPS[1] != 1)
		{
			System.out.println("Up");
			nav[0] = 0;//x coordinate remain the same
			nav[1] = -1;//y changes up means the reduce in coordinate-> negative
		}
		else if(at.getType() == right.getType() && GPS[0] != -1)
		{
			System.out.println("Right");
			nav[0] = 1;
			nav[1] = 0;
		}
		else if(at.getType() == down.getType() && GPS[1] != -1)
		{
			System.out.println("Down");
			nav[0] = 0;
			nav[1] = 1; // down means the y axis increased it's number
		}
		else if(at.getType() == left.getType() && GPS[0] != 1)
		{
			System.out.println("Left");
			nav[0] = -1;
			nav[1] = 0;
		}
		else
		{
			System.out.println("End");
			nav[0] = 2;
			nav[1] = 2;
		}
		return nav;
		//it compares the current position with all four possible directions, if the Square Type is the same, then follow the path
	}
	
	/**
	 * Update the frames
	 */
	public void update()
	{
		if(wait) //wait until the program finishes the first run
		{
			wait = false;
		}
		else
		{
			if(isOnNextStep())
			{
				if(rightnowcorner + 1 == Corner.size())
				System.out.println("Dead End!");
				else
				rightnowcorner++;
				System.out.println("We have "+rightnowcorner+ "steps in reality");
			}
			else
			{
				x = x + Delta() * Corner.get(rightnowcorner).getHDir() * speed;
				y = y + Delta() * Corner.get(rightnowcorner).getVDir() * speed;
			}
		}
	}
	/**
	 * Draw Squares/image on the screen
	 */
	public void Draw()
	{
		DrawSquareTex(tex, x, y, width, height);
	}
	/**
	 * Get the width of a monster
	 * @return
	 */
	public int getWidth() {
		return width;
	}

	/**
	 * Set the width of a monster
	 * @param width
	 */
	public void setWidth(int width) {
		this.width = width;
	}

	/**
	 * Get the Height of a Monster
	 * @return
	 */
	public int getHeight() {
		return height;
	}

	/**
	 * Set the Height of a Monster
	 * @param height
	 */
	public void setHeight(int height) {
		this.height = height;
	}

	/**
	 * get the HP of a Monster
	 * @return JP
	 */
	public int getHp() {
		return hp;
	}

	/**
	 * Set HP of a Monster
	 * @param hp
	 */
	public void setHp(int hp) {
		this.hp = hp;
	}

	/**
	 * Get the X Coordinate of a Monster
	 * @return X
	 */
	public float getX() {
		return x;
	}

	/**
	 * Set the X Coordinate of a Monster
	 * @param x
	 */
	public void setX(float x) {
		this.x = x;
	}

	/**
	 * Get Y Coordinate of a Monster
	 * @return Y
	 */
	public float getY() {
		return y;
	}

	/**
	 * Set Y Coordinate of a Monster
	 * @param y
	 */
	public void setY(float y) {
		this.y = y;
	}

	/**
	 * Get the map the monster is in
	 * @return Grid
	 */
	public Grid getGrid()
	{
		return g;
	}
	
	/**
	 * Get monsters' speed
	 * @return Speed
	 */
	public float getSpeed() {
		return speed;
	}

	/**
	 * Set monsters' speed
	 * @param speed
	 */
	public void setSpeed(float speed) {
		this.speed = speed;
	}

	/**
	 * Get the image of a square
	 * @return texture
	 */
	public Texture getTex() {
		return tex;
	}

	/**
	 * Set the image of a Square
	 * @param tex
	 */
	public void setTex(Texture tex) {
		this.tex = tex;
	}

	/**
	 * Get the square that the monster is standing on
	 */
	public Square getS() {
		return s;
	}
	/**
	 * Set the Square that the monster is standing on
	 * @param s
	 */
	public void setS(Square s) {
		this.s = s;
	}

	/**
	 * whether the program ignore the first frame update or not
	 * @return wait
	 */
	public boolean isWait() {
		return wait;
	}
	/**
	 * Set Wait
	 * @param wait
	 */
	public void setWait(boolean wait) {
		this.wait = wait;
	}

}
