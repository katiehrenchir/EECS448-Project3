/*
* @author Yehan Li
* @file main.cpp
* @since 30 October 2016
* @brief A Tower Defense Program.
* Watched tutorials that helped me from the flowing websites:
* 
* https://www.youtube.com/watch?v=H3Dn1CQsREw
* https://www.youtube.com/watch?v=Euiqdd09n68
* https://www.youtube.com/watch?v=7QDz81jMsF8
* https://www.youtube.com/watch?v=uwp-xW0kylc&t=5s
* https://www.youtube.com/watch?v=qoi6ASLK7iI
* https://www.youtube.com/watch?v=0v56I5UWrYY&list=PL19F2453814E0E315
*/
package eecs448.project;

import java.util.ArrayList;
import static MyAsistant.Time.*;

public class Group {

	private float lSpawn, SpawnT;
	private Monster t;
	private ArrayList<Monster> Mlist;
	/**
	 * 
	 * @param SpawnT Spawn Time 
	 * @param t a monster
	 */
	public Group(float SpawnT, Monster t)
	{
		this.t = t;
		this.SpawnT = SpawnT;
		lSpawn = 0;
		Mlist = new ArrayList<Monster>();
	}
	
	/**
	 * Populate the monster group and show it on the window
	 */
	public void update()
	{
		lSpawn += Delta();
		if(lSpawn > SpawnT)
		{
			Spawn();
			lSpawn = 0;
		}
		
		for (Monster m: Mlist)
		{
			m.update();
			m.Draw();
		}
	}
	
	/**
	 * Spawn a Monster
	 */
	public void Spawn()
	{
		Mlist.add(new Monster(t.getTex(), t.getGrid(), t.getS(), 64, 64, t.getSpeed()));
	}
}
