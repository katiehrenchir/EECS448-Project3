/*
* @author Yehan Li
* @file main.cpp
* @since 30 October 2016
* @brief A Tower Defense Program.
* Watched tutorials that helped me from the flowing websites:
* 
* https://www.youtube.com/watch?v=H3Dn1CQsREw
* https://www.youtube.com/watch?v=Euiqdd09n68
* https://www.youtube.com/watch?v=7QDz81jMsF8
* https://www.youtube.com/watch?v=uwp-xW0kylc&t=5s
* https://www.youtube.com/watch?v=qoi6ASLK7iI
* https://www.youtube.com/watch?v=0v56I5UWrYY&list=PL19F2453814E0E315
*/
package eecs448.project;

public class ChangeDirection //save the next step and direction
{
	private Square turn; //the current square
	private int VDir, HDir;//the direction of a square
	
	/**
	 * Constructor
	 * @param turn A Corner
	 * @param HDir The X direction
	 * @param VDir The Y direction
	 */
	public ChangeDirection(Square turn, int HDir, int VDir)
	{
		this.turn = turn;
		this.VDir = VDir;
		this.HDir = HDir;
		
	}

	/**
	 * Get the Corner
	 * @return
	 */
	public Square getTurn() {
		return turn;
	}

	/**
	 * Get the Y direction
	 * @return Y direction
	 */
	public int getVDir() {
		return VDir;
	}

	/**
	 * Get the X direction
	 * @return X direction
	 */
	public int getHDir() {
		return HDir;
	}

}
