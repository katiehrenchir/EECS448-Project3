package Main;

/**
 * The orignal source code, file structure, etc was found in the following links:
 * @link: https://youtu.be/9dzhgsVaiSo
 * https://youtu.be/qJpdRFvSj1A
 * https://youtu.be/z9llRG1lLOU
 * https://youtu.be/zUOkojY_Ylo
 * 
 * Edited/Modified by: Mac Crider
 * Original Resources (art, animation, maps) by: Mac Crider
 * 
 * 
 */

import javax.swing.JFrame;

public class Game {

	public static void main(String[] args) {
		
		JFrame window = new JFrame("Dash");
		window.setContentPane(new GamePanel());
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setResizable(false);
		window.pack();
		window.setVisible(true);
		
	}

}
