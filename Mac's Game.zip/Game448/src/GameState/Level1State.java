package GameState;

import java.awt.*;
import java.awt.event.KeyEvent;

import GameState.GameStateManager;
import Main.GamePanel;
import TileMap.*;
import Entity.*;


public class Level1State extends GameState {
	
	private TileMap tileMap;
	private Background bg;
	
	private Player player;
	
	public Level1State(GameStateManager gsm) {
		this.gsm = gsm;
	
		init(); // initialize Level1
	}
	
	public void init() {
		// initiate and load foreground tiles
		tileMap = new TileMap(16);
		tileMap.loadTiles("/Tilesets/testGround.gif");
		tileMap.loadMap("/Maps/level1Map.txt");
		tileMap.setPosition(0, 0);
		tileMap.setBetween(0.15);		
		
		bg = new Background("/Backgrounds/menu_sunset_bg.png", 1);
	
		// initiate player
		player = new Player(tileMap);
		player.setPosition(100,150);
	}

	public void update() {
		// update player
		player.update();
		tileMap.setPosition(
				GamePanel.WIDTH / 2 - player.getx(),
				GamePanel.HEIGHT / 2 - player.gety()
		);
		
		bg.setPosition(tileMap.getx() / 2, tileMap.gety() / 2);
		
		if(player.isDead()){
			try {
				gsm.setState(GameStateManager.MENUSTATE);
			} catch (Exception e){
				e.printStackTrace();
			}
		}
	}
	
	
	public void draw(Graphics2D g) {
		// draw background:
		//g.setColor(Color.PINK);
		//g.fillRect(0, 0, GamePanel.WIDTH, GamePanel.HEIGHT);
		bg.draw(g);
		
		// draw tilemap
		tileMap.draw(g);
		
		// draw player
		player.draw(g);
	}
	
	public void keyPressed(int k) {
		if(k==KeyEvent.VK_LEFT)	 player.setLeft(true);
		if(k==KeyEvent.VK_RIGHT) player.setRight(true);
		if(k==KeyEvent.VK_UP)	 player.setUp(true);
		if(k==KeyEvent.VK_DOWN)	 player.setDown(true);
		if(k==KeyEvent.VK_SPACE) player.setJumping(true);
		if(k==KeyEvent.VK_ESCAPE) gsm.setState(GameStateManager.MENUSTATE);
	}
	
	public void keyReleased(int k) {
		if(k==KeyEvent.VK_LEFT)	 player.setLeft(false);
		if(k==KeyEvent.VK_RIGHT) player.setRight(false);
		if(k==KeyEvent.VK_UP)	 player.setUp(false);
		if(k==KeyEvent.VK_DOWN)	 player.setDown(false);
		if(k==KeyEvent.VK_SPACE) player.setJumping(false);
	}

}
